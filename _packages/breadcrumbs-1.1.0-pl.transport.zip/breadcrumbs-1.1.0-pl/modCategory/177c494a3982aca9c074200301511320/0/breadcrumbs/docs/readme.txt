--------------------
Snippet: Breadcrumbs
--------------------
Version: 1.0
Date: 2008.10.08
Author: jaredc@honeydewdesign.com
Editor: Shaun McCormick <shaun@collabpad.com>
Honorable mentions:
- Bill Wilson
- wendy@djamoer.net
- grad

This snippet was designed to show the path through the various levels of site structure
back to the root. It is NOT necessarily the path the user took to arrive at a given
page.